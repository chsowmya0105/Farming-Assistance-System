package com.cg.fas.service;

import java.util.List;

import com.cg.fas.DTO.ComplaintDTO;
import com.cg.fas.DTO.FarmerDTO;
import com.cg.fas.DTO.LoginDTO;


public interface FarmerService {

	public LoginDTO login(LoginDTO loginDTO);

	public FarmerDTO updateFarmer(FarmerDTO farmerDTO);

	public ComplaintDTO addComplaint(ComplaintDTO complaintDTO);

	public FarmerDTO addFarmer(FarmerDTO farmerDTO);

	public FarmerDTO getFarmerById(int farmerId);
	
	public List<FarmerDTO> findAll();
	
	public Boolean deleteFarmer(FarmerDTO farmerDTO);
}
