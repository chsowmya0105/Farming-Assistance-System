package com.cg.fas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fas.DTO.CropDTO;
import com.cg.fas.service.CropService;

@RestController

@RequestMapping("/crop")
public class CropController {
	
	@Autowired
	private CropService cropService;
	
	// http://localhost:9000/crop/addCrop
		@PostMapping("/addCrop")
		public CropDTO addCrop(@RequestBody CropDTO cropDTO) {
			return cropService.addCrop(cropDTO);
		}
		
		// http://localhost:9000/crop/updateCrop
	     @PutMapping("/updateCrop")
		public CropDTO updateFarmer(@RequestBody CropDTO cropDTO)
		{
			return cropService.updateCrop(cropDTO);
	    }
	     
	     
	  // http://localhost:9000/crop/deleteCrop
	     @DeleteMapping("/deleteCrop")
		public Boolean deleteCrop(@RequestBody CropDTO cropDTO)
		{
			return cropService.deleteCrop(cropDTO);
	    }

}
