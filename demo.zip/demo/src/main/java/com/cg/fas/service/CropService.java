package com.cg.fas.service;

import com.cg.fas.DTO.CropDTO;

public interface CropService {

	public CropDTO addCrop(CropDTO cropDTO);

	public CropDTO updateCrop(CropDTO cropDTO);

	public Boolean deleteCrop(CropDTO cropDTO);

}
