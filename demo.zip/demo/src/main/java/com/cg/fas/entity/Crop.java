package com.cg.fas.entity;
import javax.persistence.*;

@Entity
public class Crop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Long quantity;
    private Double sellingPrice;
    private Long farmerId;
    private Long supplierId;
    private Double buyingPrice;
    
   // @ManyToMany(cascade = CascadeType.ALL)
   // @JoinColumn(name = "farmerId")
  // public List<Farmer> farmerList = new ArrayList<>();
    
   // @ManyToMany(cascade = CascadeType.ALL)
  //  @JoinColumn(name = "supplierId")
  // public List<Supplier> SupplierList = new ArrayList<>();
    
   // @ManyToOne(cascade = CascadeType.ALL)
  //  @JoinColumn(name ="supplierAdvertisement")
   // private SupplierAdvertisement supplierAdvertisement;
    
    

	public Crop() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Crop(String name, Long quantity, Double sellingPrice, Long farmerId, Long supplierId, Double buyingPrice) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.sellingPrice = sellingPrice;
		this.farmerId = farmerId;
		this.supplierId = supplierId;
		this.buyingPrice = buyingPrice;
//		this.farmerList = farmerList;
//		this.SupplierList = supplierList;
//		this.supplierAdvertisement = supplierAdvertisement;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public Long getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(Long farmerId) {
		this.farmerId = farmerId;
	}

	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

	public Double getBuyingPrice() {
		return buyingPrice;
	}

	public void setBuyingPrice(Double buyingPrice) {
		this.buyingPrice = buyingPrice;
	}

//	public List<Farmer> getFarmerList() {
//		return farmerList;
//	}
//
//	public void setFarmerList(List<Farmer> farmerList) {
//		this.farmerList = farmerList;
//	}
//
//	public List<Supplier> getSupplierList() {
//		return SupplierList;
//	}
//
//	public void setSupplierList(List<Supplier> supplierList) {
//		SupplierList = supplierList;
//	}
//
//	public SupplierAdvertisement getSupplierAdvertisement() {
//		return supplierAdvertisement;
//	}
//
//	public void setSupplierAdvertisement(SupplierAdvertisement supplierAdvertisement) {
//		this.supplierAdvertisement = supplierAdvertisement;
//	}

	@Override
	public String toString() {
		return "Crop [id=" + id + ", name=" + name + ", quantity=" + quantity + ", sellingPrice=" + sellingPrice
				+ ", farmerId=" + farmerId + ", supplierId=" + supplierId + ", buyingPrice=" + buyingPrice
				+ "]";
	}
    
    

   
}