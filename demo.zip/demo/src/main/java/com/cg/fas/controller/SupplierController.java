package com.cg.fas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fas.DTO.LoginDTO;
import com.cg.fas.DTO.SupplierDTO;
import com.cg.fas.service.SupplierService;
@RestController
@RequestMapping(name = "/suppliers")
public class SupplierController {
	@Autowired
	private SupplierService supplierService;
	
	// http://localhost:9000/farmers/login
    @PostMapping("/login")
	public LoginDTO login(@RequestBody LoginDTO loginDTO) {
		return supplierService.login(loginDTO);
	}

	// http://localhost:9000/suppliers/updateSupplier
	@PutMapping("/updateSupplier")
	public SupplierDTO updateSupplier(@RequestBody SupplierDTO supplierDTO) {
		return supplierService.updateSupplier(supplierDTO);
	}
	
	// http://localhost:9000/suppliers/addSupplier
	@PostMapping("/addSupplier")
	public SupplierDTO addSupplier(SupplierDTO supplierDTO)
	{
		return supplierService.addSupplier(supplierDTO);
	}
	
	 // http://localhost:9000/suppliers/deleteSupplier
    @DeleteMapping("/deleteSupplier")
	public Boolean deleteSupplier(@RequestBody SupplierDTO supplierDTO)
	{
		return supplierService.deleteSupplier(supplierDTO);
   }
	
	
	
}
