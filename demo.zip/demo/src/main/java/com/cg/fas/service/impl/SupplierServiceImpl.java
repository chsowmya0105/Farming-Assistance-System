package com.cg.fas.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fas.DTO.LoginDTO;
import com.cg.fas.DTO.SupplierDTO;
import com.cg.fas.entity.Login;
import com.cg.fas.entity.Supplier;
import com.cg.fas.repository.SupplierRepository;
import com.cg.fas.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService {

	@Autowired
	private SupplierRepository repository;

	@Override
	public LoginDTO login(LoginDTO loginDTO) {
		Login login = new Login();
		BeanUtils.copyProperties(loginDTO, login);
		repository.save(login);
        return loginDTO;
	}

	@Override
	public SupplierDTO addSupplier(SupplierDTO supplierDTO) {
		Supplier supplier = new Supplier();
		BeanUtils.copyProperties(supplierDTO, supplier);
		repository.save(supplier);
        return supplierDTO;
	}

	@Override
	public SupplierDTO updateSupplier(SupplierDTO supplierDTO) {
		Supplier supplier = new Supplier();
		BeanUtils.copyProperties(supplierDTO, supplier);
		repository.save(supplier);
        return supplierDTO;
		
	}

	@Override
	public Boolean deleteSupplier(SupplierDTO supplierDTO) {
		Supplier supplier = new Supplier();
		BeanUtils.copyProperties(supplierDTO, supplier);
		repository.save(supplier);
        return true;
		
	}
	
	

}
