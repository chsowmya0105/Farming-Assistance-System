package com.cg.fas.entity;

import javax.persistence.*;

@Entity
@Table(name = "Complaint")
public class Complaint {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long farmerId;

	private String complaintDescription;

	//@ManyToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name = "adminId")
	//private Admin admin;
	//@OneToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name = "farmerId")
	//private Farmer farmer;
	
	//@OneToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name = "complaint")
	//private Supplier supplier;
	
	

	public Complaint() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Complaint(Long farmerId, String complaintDescription) {
		super();
		this.farmerId = farmerId;
		this.complaintDescription = complaintDescription;
//		this.admin = admin;
//		this.farmer = farmer;
//		this.supplier = supplier;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(Long farmerId) {
		this.farmerId = farmerId;
	}

	public String getComplaintDescription() {
		return complaintDescription;
	}

	public void setComplaintDescription(String complaintDescription) {
		this.complaintDescription = complaintDescription;
	}

//	public Admin getAdmin() {
//		return admin;
//	}
//
//	public void setAdmin(Admin admin) {
//		this.admin = admin;
//	}
//
//	public Farmer getFarmer() {
//		return farmer;
//	}
//
//	public void setFarmer(Farmer farmer) {
//		this.farmer = farmer;
//	}
//
//	public Supplier getSupplier() {
//		return supplier;
//	}
//
//	public void setSupplier(Supplier supplier) {
//		this.supplier = supplier;
//	}

	@Override
	public String toString() {
		return "Complaint [id=" + id + ", farmerId=" + farmerId + ", complaintDescription=" + complaintDescription
				+  "]";
	}
	

	
}