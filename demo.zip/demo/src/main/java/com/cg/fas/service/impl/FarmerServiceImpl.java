package com.cg.fas.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fas.DTO.FarmerDTO;
import com.cg.fas.DTO.LoginDTO;
import com.cg.fas.entity.Complaint;
import com.cg.fas.entity.Farmer;
import com.cg.fas.entity.Login;
import com.cg.fas.repository.FarmerRepository;
import com.cg.fas.DTO.ComplaintDTO;
import com.cg.fas.service.FarmerService;

@Service
public class FarmerServiceImpl implements FarmerService {
	
	@Autowired
	private FarmerRepository repository;

	@Override
	public LoginDTO login(LoginDTO loginDTO) {
		Login login = new Login();
		BeanUtils.copyProperties(loginDTO, login);
		repository.save(login);
        return loginDTO;
		
	}

	@Override
	public FarmerDTO updateFarmer(FarmerDTO farmerDTO) {
		Farmer farmer = new Farmer();
		BeanUtils.copyProperties(farmerDTO, farmer);
		repository.save(farmer);
        return farmerDTO;
		
	}

	@Override
	public ComplaintDTO addComplaint(ComplaintDTO complaintDTO) {
		Complaint complaint = new Complaint();
		BeanUtils.copyProperties(complaintDTO, complaint);
		repository.save(complaint);
        return complaintDTO;
	}

	@Override
	public FarmerDTO addFarmer(FarmerDTO farmerDTO) {
		Farmer farmer = new Farmer();
		BeanUtils.copyProperties(farmerDTO, farmer);
		repository.save(farmer);
        return farmerDTO;
		
	}

	@Override
	public FarmerDTO getFarmerById(int farmerId) {
		Optional<Farmer> farmer = repository.findById(farmerId);
		if(farmer.isPresent())
		{
			FarmerDTO dto = new FarmerDTO();
			BeanUtils.copyProperties(farmer.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<FarmerDTO> findAll() {
		Iterable<Farmer> list = repository.findAll();
		List<FarmerDTO> dtos = new ArrayList<>();
		for(Farmer farmer : list)
		{
			FarmerDTO dto = new FarmerDTO();
			BeanUtils.copyProperties(farmer, dto);
			dtos.add(dto);
		}
		return dtos;
	}

	@Override
	public Boolean deleteFarmer(FarmerDTO farmerDTO) {
		Farmer farmer = new Farmer();
		BeanUtils.copyProperties(farmerDTO, farmer);
		repository.delete(farmer);
        return true;
		
	}

}
