package com.cg.fas.repository;


import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.fas.entity.Complaint;
import com.cg.fas.entity.Farmer;
import com.cg.fas.entity.Login;

@Repository
public interface FarmerRepository extends CrudRepository<Farmer, Long> {

	Farmer findByUsername(String username);

	void save(Login login);

	void save(Complaint complaint);

	Optional<Farmer> findById(int farmerId);

	


}
