package com.cg.fas.service;


import com.cg.fas.DTO.LoginDTO;
import com.cg.fas.DTO.SupplierDTO;

public interface SupplierService {

	public LoginDTO login(LoginDTO loginDTO);
	
	public SupplierDTO addSupplier(SupplierDTO supplierDTO);
	
	public SupplierDTO updateSupplier(SupplierDTO supplierDTO);

	public Boolean deleteSupplier(SupplierDTO supplierDTO);

}
