package com.cg.fas.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.fas.DTO.AdminDTO;
import com.cg.fas.entity.Admin;
import com.cg.fas.entity.Login;
@Repository
public interface AdminRepository extends CrudRepository<Admin, Integer> {

	void save(AdminDTO adminDTO);

	void save(Login login);

	

}
