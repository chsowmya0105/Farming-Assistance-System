package com.cg.fas.service;

import com.cg.fas.DTO.ComplaintDTO;

public interface ComplaintService {

	public ComplaintDTO addComplaint(ComplaintDTO complaintDTO);

	public Boolean deleteComplaint(ComplaintDTO complaintDTO);

}
