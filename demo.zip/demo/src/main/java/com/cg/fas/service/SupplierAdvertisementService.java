package com.cg.fas.service;

import org.springframework.stereotype.Service;

import com.cg.fas.DTO.SupplierAdvertisementDTO;

@Service
public interface SupplierAdvertisementService {
	
	public SupplierAdvertisementDTO addAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO);
	
	public SupplierAdvertisementDTO updateAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO);
	
	public Boolean deleteAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO);
	
	

}
