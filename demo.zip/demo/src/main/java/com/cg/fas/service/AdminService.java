package com.cg.fas.service;

import com.cg.fas.DTO.LoginDTO;

public interface AdminService {

	public LoginDTO login(LoginDTO loginDTO);

	

}
