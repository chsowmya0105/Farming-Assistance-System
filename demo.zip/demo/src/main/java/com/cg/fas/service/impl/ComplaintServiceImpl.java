package com.cg.fas.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fas.DTO.ComplaintDTO;
import com.cg.fas.entity.Complaint;
import com.cg.fas.repository.ComplaintRepository;
import com.cg.fas.service.ComplaintService;
@Service
public class ComplaintServiceImpl implements ComplaintService {

	@Autowired
	private ComplaintRepository repository;
	@Override
	public ComplaintDTO addComplaint(ComplaintDTO complaintDTO) {
		Complaint complaint = new Complaint();
		BeanUtils.copyProperties(complaintDTO, complaint);
		repository.save(complaint);
        return complaintDTO;
		
	}

	@Override
	public Boolean deleteComplaint(ComplaintDTO complaintDTO) {
		
		Complaint complaint = new Complaint();
		BeanUtils.copyProperties(complaintDTO, complaint);
		repository.delete(complaint);
        return true;
	}

}
