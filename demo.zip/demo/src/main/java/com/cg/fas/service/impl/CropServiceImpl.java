package com.cg.fas.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fas.DTO.CropDTO;
import com.cg.fas.entity.Crop;
import com.cg.fas.repository.CropRepository;
import com.cg.fas.service.CropService;

@Service
public class CropServiceImpl implements CropService {
	@Autowired
	private CropRepository repository;

	@Override
	public CropDTO addCrop(CropDTO cropDTO) {
		Crop crop = new Crop();
		BeanUtils.copyProperties(cropDTO, crop);
		repository.save(crop);
        return cropDTO;
		
	}

	@Override
	public CropDTO updateCrop(CropDTO cropDTO) {
		Crop crop = new Crop();
		BeanUtils.copyProperties(cropDTO, crop);
		repository.save(crop);
        return cropDTO;
	}

	@Override
	public Boolean deleteCrop(CropDTO cropDTO) {

		Crop crop = new Crop();
		BeanUtils.copyProperties(cropDTO, crop);
		repository.delete(crop);
        return true;
	}

}
