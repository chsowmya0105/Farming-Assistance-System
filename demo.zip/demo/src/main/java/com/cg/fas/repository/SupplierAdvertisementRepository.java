package com.cg.fas.repository;

import com.cg.fas.entity.SupplierAdvertisement;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface SupplierAdvertisementRepository extends CrudRepository<SupplierAdvertisement, Long>
{

	

}
