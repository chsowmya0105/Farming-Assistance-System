package com.cg.fas.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.fas.entity.Login;
import com.cg.fas.entity.Supplier;
@Repository
public interface SupplierRepository extends CrudRepository<Supplier, Long>{

	void save(Login login);

//	void save(Login login);
//
//	SupplierDTO updateSupplier(SupplierDTO supplierDTO);
//
//	SupplierDTO getSupplierById(SupplierDTO supplierDTO);
//
//	SupplierDTO addSupplier(SupplierDTO supplierDTO);
//
//	Boolean deleteSupplier(SupplierDTO supplierDTO);
//
//	LoginDTO login(LoginDTO loginDTO);

}
