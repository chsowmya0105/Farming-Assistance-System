package com.cg.fas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fas.DTO.SupplierAdvertisementDTO;
import com.cg.fas.service.SupplierAdvertisementService;

@RestController
@RequestMapping("/supplierAdvertisement")
public class SupplierAdvertisementController {
	
	@Autowired
	private SupplierAdvertisementService supplierAdvertisementService;
	
	// http://localhost:9000/supplierAdvertisement/addAdvertisement
	@PostMapping("/addAdvertisement")
	public SupplierAdvertisementDTO addAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO)
	{
		return supplierAdvertisementService.addAdvertisement(supplierAdvertisementDTO);
	}
	
	// http://localhost:9000/supplierAdvertisement/updateAdvertisement
		@PostMapping("/updateAdvertisement")
		public SupplierAdvertisementDTO updateAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO)
		{
			return supplierAdvertisementService.updateAdvertisement(supplierAdvertisementDTO);
		}
		
		// http://localhost:9000/supplierAdvertisement/deleteAdvertisement
	     @DeleteMapping("/deleteAdvertisement")
		public Boolean deleteAdvertisement(@RequestBody SupplierAdvertisementDTO supplierAdvertisementDTO)
		{
			return supplierAdvertisementService.deleteAdvertisement(supplierAdvertisementDTO);
	    }
		

}
