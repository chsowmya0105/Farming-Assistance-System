package com.cg.fas.DTO;

public class SupplierAdvertisementDTO {
	private long id;
	private long cropId;
	private long supplierId;
	private double askedPrice;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getCropId() {
		return cropId;
	}
	public void setCropId(long cropId) {
		this.cropId = cropId;
	}
	public long getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(long supplierId) {
		this.supplierId = supplierId;
	}
	public double getAskedPrice() {
		return askedPrice;
	}
	public void setAskedPrice(double askedPrice) {
		this.askedPrice = askedPrice;
	}
	
	

}
