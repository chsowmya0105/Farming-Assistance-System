package com.cg.fas.controller;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.fas.DTO.ComplaintDTO;
import com.cg.fas.DTO.FarmerDTO;
import com.cg.fas.DTO.LoginDTO;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//
//
//import com.cg.fas.entity.Admin;
//import com.cg.fas.entity.Complaint;
//import com.cg.fas.entity.Farmer;
import com.cg.fas.service.FarmerService;

@RestController

@RequestMapping("/farmers")

public class FarmerController {

	@Autowired
	private FarmerService farmerService;
	// http://localhost:9000/farmers/login
    @PostMapping("/login")
	public LoginDTO login(@RequestBody LoginDTO loginDTO) {
		return farmerService.login(loginDTO);
	}

	// http://localhost:9000/farmers/addComplaint
	@PostMapping("/addComplaint")
	public ComplaintDTO addComplaint(@RequestBody ComplaintDTO complaintDTO) {
		return farmerService.addComplaint(complaintDTO);
	}

	// http://localhost:9000/farmers/addFarmer
	@PostMapping("/addFarmer")
	public FarmerDTO addFarmer(@RequestBody FarmerDTO farmerDTO) {
		return farmerService.addFarmer(farmerDTO);
	}
	// http://localhost:9000/farmers/updateFarmer
     @PutMapping("/updateFarmer")
	public FarmerDTO updateFarmer(@RequestBody FarmerDTO farmerDTO)
	{
		return farmerService.updateFarmer(farmerDTO);
    }
 	// http://localhost:9000/farmers/getFarmerById
     @GetMapping("/getFarmerById")
    public  FarmerDTO getFarmerById(@RequestBody int farmerId)
    {
    	return farmerService.getFarmerById(farmerId);
    }
     
     // http://localhost:9000/farmers/deleteFarmer
     @DeleteMapping("/deleteFarmer")
	public Boolean deleteFarmer(@RequestBody FarmerDTO farmerDTO)
	{
		return farmerService.deleteFarmer(farmerDTO);
    }
     
     
      
}
