package com.cg.fas.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Supplier")
public class Supplier {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String username;
	private String firstName;
	private String lastName;
	private Long pincode;
	private String phnNumber;

	//@OneToOne(mappedBy = "supplier")
	//private Complaint complaint;

	//@ManyToMany(mappedBy = "supplier")
	//List<Crop> cropList = new ArrayList<>();
	
	

	public Supplier() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Supplier(String username, String firstName, String lastName, Long pincode, String phnNumber) {
		super();
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pincode = pincode;
		this.phnNumber = phnNumber;
//		this.complaint = complaint;
//		this.cropList = cropList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getPincode() {
		return pincode;
	}

	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	public String getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(String phnNumber) {
		this.phnNumber = phnNumber;
	}

//	public Complaint getComplaint() {
//		return complaint;
//	}
//
//	public void setComplaint(Complaint complaint) {
//		this.complaint = complaint;
//	}
//
//	public List<Crop> getCropList() {
//		return cropList;
//	}
//
//	public void setCropList(List<Crop> cropList) {
//		this.cropList = cropList;
//	}

	@Override
	public String toString() {
		return "Supplier [id=" + id + ", username=" + username + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", pincode=" + pincode + ", phnNumber=" + phnNumber +  "]";
	}

}