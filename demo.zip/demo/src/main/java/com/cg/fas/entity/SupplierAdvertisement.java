package com.cg.fas.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SupplierAdvertisement")
public class SupplierAdvertisement implements Serializable{

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long cropId;
	private Long supplierId;
	private Double askedPrice;
	
	//@ManyToMany(cascade = CascadeType.ALL)
	//@JoinColumn(name = "farmerId") 
	//public List<Farmer> farmerList = new ArrayList<>();
	
	//@ManyToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name = "supplierId")
	//private Supplier supplier;
	
	//@OneToMany(cascade = CascadeType.ALL)
	//@JoinColumn(name = "Crop")
	//public List<Crop> CropList = new ArrayList<>();
	
	
	public SupplierAdvertisement() {
		super();
		// TODO Auto-generated constructor stub
	}


	public SupplierAdvertisement(Long cropId, Long supplierId, Double askedPrice) {
		super();
		this.cropId = cropId;
		this.supplierId = supplierId;
		this.askedPrice = askedPrice;
//		this.farmerList = farmerList;
//		this.supplier = supplier;
//		this.CropList = cropList;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getCropId() {
		return cropId;
	}


	public void setCropId(Long cropId) {
		this.cropId = cropId;
	}


	public Long getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}


	public Double getAskedPrice() {
		return askedPrice;
	}


	public void setAskedPrice(Double askedPrice) {
		this.askedPrice = askedPrice;
	}


//	public List<Farmer> getFarmerList() {
//		return farmerList;
//	}
//
//
//	public void setFarmerList(List<Farmer> farmerList) {
//		this.farmerList = farmerList;
//	}
//
//
//	public Supplier getSupplier() {
//		return supplier;
//	}
//
//
//	public void setSupplier(Supplier supplier) {
//		this.supplier = supplier;
//	}
//
//
//	public List<Crop> getCropList() {
//		return CropList;
//	}
//
//
//	public void setCropList(List<Crop> cropList) {
//		CropList = cropList;
//	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	@Override
	public String toString() {
		return "SupplierAdvertisement [id=" + id + ", cropId=" + cropId + ", supplierId=" + supplierId
				+ ", askedPrice=" + askedPrice + "]";
	}

}