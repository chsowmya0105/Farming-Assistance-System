package com.cg.fas.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fas.DTO.SupplierAdvertisementDTO;
import com.cg.fas.entity.SupplierAdvertisement;
import com.cg.fas.repository.SupplierAdvertisementRepository;
import com.cg.fas.service.SupplierAdvertisementService;

@Service
public class SupplierAdvertisementServiceImpl implements SupplierAdvertisementService {
	
@Autowired
private SupplierAdvertisementRepository repository;
	
	@Override
	public SupplierAdvertisementDTO addAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO) {
		
		SupplierAdvertisement supplierAdvertisement = new SupplierAdvertisement();
		BeanUtils.copyProperties(supplierAdvertisementDTO, supplierAdvertisement);
		repository.save(supplierAdvertisement);
        return supplierAdvertisementDTO;
	}

	@Override
	public SupplierAdvertisementDTO updateAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO) {
		SupplierAdvertisement supplierAdvertisement = new SupplierAdvertisement();
		BeanUtils.copyProperties(supplierAdvertisementDTO, supplierAdvertisement);
		repository.save(supplierAdvertisement);
        return supplierAdvertisementDTO;
		
	}

	@Override
	public Boolean deleteAdvertisement(SupplierAdvertisementDTO supplierAdvertisementDTO) {
		SupplierAdvertisement supplierAdvertisement = new SupplierAdvertisement();
		BeanUtils.copyProperties(supplierAdvertisementDTO, supplierAdvertisement);
		repository.delete(supplierAdvertisement);
        return true;
		
	}

	
}
