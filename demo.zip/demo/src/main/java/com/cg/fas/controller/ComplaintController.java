package com.cg.fas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fas.DTO.ComplaintDTO;
import com.cg.fas.service.ComplaintService;

@RestController
@RequestMapping("/complaint")
public class ComplaintController {
	@Autowired
	private ComplaintService complaintService;
	
	// http://localhost:9000/complaint/addComplaint
		@PostMapping("/addComplaint")
		public ComplaintDTO addComplaint(@RequestBody ComplaintDTO complaintDTO) {
			return complaintService.addComplaint(complaintDTO);
		}
		
		// http://localhost:9000/complaint/deleteComplaint
	     @DeleteMapping("/deleteComplaint")
		public Boolean deleteComplaint(@RequestBody ComplaintDTO complaintDTO)
		{
			return complaintService.deleteComplaint(complaintDTO);
	    }

}
