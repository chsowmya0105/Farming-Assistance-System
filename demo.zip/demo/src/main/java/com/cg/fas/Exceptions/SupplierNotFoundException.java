package com.cg.fas.Exceptions;

public class SupplierNotFoundException extends RuntimeException {
	
	public SupplierNotFoundException()
	{
		super();
		
	}
	public SupplierNotFoundException(String message)
	{
		super(message);
	}

}
