package com.cg.fas.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Farmer")
public class Farmer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String username;
	private String firstName;
	private String lastName;

	private Long pincode;

	private String phnNumber;
	
	//@ManyToMany(mappedBy = "farmer")
	//List<Crop> cropList = new ArrayList<>();

	public Farmer() {

	}
	//@OneToOne(mappedBy = "farmer")
	//private Complaint complaint;
	
	//@ManyToMany(mappedBy = "farmer")
	//List<SupplierAdvertisement> advertisementList = new ArrayList<>();
	
	

	public Farmer(String username, String firstName, String lastName, Long pincode, String phnNumber) {
		super();
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pincode = pincode;
		this.phnNumber = phnNumber;
//		this.cropList = cropList;
//		this.complaint = complaint;
//		this.advertisementList = advertisementList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getPincode() {
		return pincode;
	}

	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	public String getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(String phnNumber) {
		this.phnNumber = phnNumber;
	}

//	public List<Crop> getCropList() {
//		return cropList;
//	}
//
//	public void setCropList(List<Crop> cropList) {
//		this.cropList = cropList;
//	}
//
//	public Complaint getComplaint() {
//		return complaint;
//	}
//
//	public void setComplaint(Complaint complaint) {
//		this.complaint = complaint;
//	}
//
//	public List<SupplierAdvertisement> getAdvertisementList() {
//		return advertisementList;
//	}
//
//	public void setAdvertisementList(List<SupplierAdvertisement> advertisementList) {
//		this.advertisementList = advertisementList;
//	}

	@Override
	public String toString() {
		return "Farmer [id=" + id + ", username=" + username + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", pincode=" + pincode + ", phnNumber=" + phnNumber +  "]";
	}
	

	
}